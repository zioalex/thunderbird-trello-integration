// background.js
// This script listens for the extension being clicked and
// sends a message to add a Trello task.

// Placeholder code
console.log('Background script loaded.');
